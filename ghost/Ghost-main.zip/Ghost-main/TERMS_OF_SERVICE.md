# Terms of Service

## Our disclaimer

This tool is designed for educational purposes only.

Adequate defenses can only be built by researching attack techniques available to malicious actors.
Using this tool against target systems without prior permission is illegal in most jurisdictions.
The authors are not liable for any damages from misuse of this information or code.

If you are planning on using this tool for malicious purposes that are not authorized by the company
you are performing assessments for, you are violating the terms of service and license. 

After installing this tool, you automatically accept our terms of service and agree
that you will use it only for lawful purposes.
